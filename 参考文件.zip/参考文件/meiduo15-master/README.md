# meiduo15
美多商城python代码

进入front文件夹cmd模式运行live-server

开启redis数据库
进入c盘找到redis文件夹进入cmd模式
执行redis-server.exe redis.windows.conf  将redis数据库启动
