from django.apps import AppConfig


class OauthConfig(AppConfig):
    name = 'oauth'
